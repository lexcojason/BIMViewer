/*
 *
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-U18
 *
 * (C) COPYRIGHT IBM CORP. 2012,2014
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 *
 */


//--------------------------------------------------------------------------
//V7600_06
//--------------------------------------------------------------------------
package psdi.script.en;

import java.io.PrintStream;
import java.sql.Connection;
import java.util.HashMap;

import psdi.configure.CommonShell;
import psdi.script.AutoUpgradeTemplate;

/**
 * Add database info to menu
 * @see #process
 */
public class V7613_330 extends AutoUpgradeTemplate
{
 
	public V7613_330(Connection con) throws Exception {
		super(con);
	}

	public V7613_330(Connection con, PrintStream ps) throws Exception {
		super(con, ps);
	}

	public V7613_330(Connection con, HashMap params, PrintStream ps)
			throws Exception {
		super(con, params, ps);
	}

    /**
	 * Initialize.
	 */
    @Override
    public void init() throws Exception
	{
    	// Name of the script file
    	scriptFileName = "V7613_330";
	} //init

	/**
	 * Add menu action
	 */

	@Override
    protected void process() throws Exception 
	{
	    super.process();
	    
		deleteBIMMenu( "BIMMODELS" );
	    
		updateBIMMenu( "BIMMODELS" );
	} // end process
	
	private void updateBIMMenu(
		String keyValue
	)
		throws Exception
	{
		
	    String menuType = "MODULE";
	    String moduleApp = "BIM";
	    String elementType = "APP";
	    String[] positionAndSub = menuGetPositionAndSub(menuType, moduleApp, "MODULE", "BIM");
	    String position = "0" + menuGetNextPosition(menuType, moduleApp, positionAndSub[0]);
	    String subposition = "0";
	    menuAddRow(menuType, moduleApp, elementType, keyValue, position, subposition, null);
		
	}
	
	private void deleteBIMMenu(
		String keyValue
	)
		throws Exception
	{
		
		String stmt = "delete from maxmenu where menutype = 'MODULE' and moduleapp = 'BIM' and elementtype = 'APP' and keyvalue = '{1}'";
		stmt = stmt.replace( "{1}", keyValue );
		String sql = stmt;
        if (util.dbOut == DB2)
        {
        	sql = CommonShell.reformatForDB2(con, stmt);
        }
        else if(util.dbOut == SQLSERVER)
        {
        	sql = CommonShell.reformatForSqlsvr(con, stmt);
        }        	
		executeSql(sql);
		
	}

} //end of class V7600_06
