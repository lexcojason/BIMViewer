/*
 *
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-U18
 *
 * (C) COPYRIGHT IBM CORP. 2016
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been
 * deposited with the U.S. Copyright Office.
 *
 */

/* 
 * @author Adalziso Francischine
 */

package psdi.script.en;

import java.io.PrintStream;
import java.sql.Connection;
import java.util.HashMap;

import psdi.script.MsgProcSwitchOver;

public class V7613_331 extends MsgProcSwitchOver {

	public V7613_331(Connection con, HashMap params, PrintStream ps)
			throws Exception {
		super(con, params, ps);
	}
}
